# RocketMQ Spring Boot Support
This project provides auto-configuration for the following RocketMQ client:

- [Produce and Consume Spring Message](../rocketmq-spring-boot-starter)
- [Send (halp) Message in Transaction](../rocketmq-spring-boot-starter)

For details, please see sample code in the [rocketmq-spring-boot-samples](../rocketmq-spring-boot-samples)